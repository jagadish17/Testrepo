const reporter = require('cucumber-html-reporter');
const fs = require('fs');
const path = require('path');

const jsonFile = './allure-results/results.json'; // Path to the cucumber JSON results file
const screenshotDir = './screenshots'; // Screenshot directory
const outputDir = './reports/cucumber-html-report.html'; // Output path for the HTML report

const options = {
  theme: 'bootstrap',
  jsonFile,  // Path to your cucumber JSON results file
  output: outputDir, // Path where the HTML report will be saved
  reportSuiteAsScenarios: true,
  launchReport: true,
  screenshotsFolder: screenshotDir, // Folder containing screenshots
  inline: true // Inline ima
};

reporter.generate(options);
