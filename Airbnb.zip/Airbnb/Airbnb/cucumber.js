module.exports = 
{
  "default": {
    require: ["tests/support/hooks.js", "tests/step-definitions/**/*.js","tests/pages/**/*.js"],
    format: [
     "json:./allure-results/results.json"  // Cucumber will output results here
    ],
    paths: ["tests/features/**/AirbnbLoginandCheckin.js"]
  }
  }
