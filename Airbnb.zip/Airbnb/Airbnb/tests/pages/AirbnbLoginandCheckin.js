const { expect } = require('@playwright/test');


class AirbnbPage {
    constructor(page) {
        if (!page) throw new Error("Page instance is required!");
        this.page = page;
        this.destinationField = "//*[@id='bigsearch-query-location-input']";
        this.destinationDropdownOption = "text=United States";
        this.checkinDateField = "//*[@data-testid='structured-search-input-field-split-dates-0']";
        this.checkoutDateField = "//*[@data-testid='structured-search-input-field-split-dates-1']";
        this.addGuestButton = "//*[@data-testid='structured-search-input-field-guests-button']";
        this.addAdultButton = "//*[@data-testid='stepper-adults-increase-button']";
        this.addChildButton = "//*[@data-testid='stepper-children-increase-button']";
        this.addInfantButton = "//*[@data-testid='stepper-infants-increase-button']";
        this.searchButton = "//*[@class='c1nkokj4 atm_9s_116y0ak atm_l8_exct8b atm_mk_h2mmj6 atm_wq_kb7nvz dir dir-ltr']";
        this.searchResults = ".search-results"; // Replace with actual search result container selector
    }

    async navigate() {
        await this.page.goto('https://www.airbnb.co.in/');
    }

    async enterDestination() {
        await this.page.fill(this.destinationField, 'United States');
    }

    async selectDestination() {
        await this.page.click(this.destinationDropdownOption);
    }

    async chooseCheckinDate() {
        await this.page.click(this.checkinDateField);
        await this.page.click("//td[@data-testid='calendar-day-2025-03-25']"); // Adjust as needed
    }

    async chooseCheckoutDate() {
        await this.page.click(this.checkoutDateField);
        await this.page.click("//td[@data-testid='calendar-day-2025-04-16']"); // Adjust as needed
    }

    async clickAddGuest() {
        await this.page.click(this.addGuestButton);
    }

    async addAdultGuest() {
        await this.page.click(this.addAdultButton);
    }

    async addChildGuest() {
        await this.page.click(this.addChildButton);
    }

    async addInfantGuest() {
        await this.page.click(this.addInfantButton);
    }

    async clickSearchButton() {
        await this.page.click(this.searchButton);
    }

    async verifySearchResults() {
        await this.page.waitForSelector(this.searchResults);
        const resultsText = await this.page.textContent(this.searchResults);
        expect(resultsText).toContain('United States');
    }
}

module.exports = AirbnbPage;
