const XLSX = require('xlsx');

/**
 * Reads data from an Excel file and converts it into JSON.
 * @param {string} filePath - Path to the Excel file.
 * @param {string} sName
 * @returns {Array} - Array of objects representing rows in the Excel file.
 */
function readExcelData(filePath,sName) {
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[sName];
    const worksheet = workbook.Sheets[sheetName];
    return XLSX.utils.sheet_to_json(worksheet);
}

/**
 * Compares data from a web table with an Excel file.
 * @param {object} page - The Playwright page object.
 * @param {string} excelFilePath - Path to the Excel file.
 * @returns {boolean} - Returns true if all rows match; otherwise, false.
 */
async function compareWebTableWithExcel(rows, excelFilePath,sName) {
    const excelData = readExcelData(excelFilePath,sName);
    let isMatched = true;

    for (let i = 0; i < rows.length; i++) {
        const cells = await rows[i].$$('td');
        const webRowData = {
            ProjectID: await cells[0].textContent(),
            ProjectName: await cells[1].textContent(),
            Supervisor: await cells[2].textContent(),
            Involvement: await cells[3].textContent(),
            Role: await cells[4].textContent(),
            Deputation: await cells[5].textContent(),
            StartDate: await cells[6].textContent(),
            EndDate: await cells[7].textContent(),
        };

        const matchingRow = excelData.find(row =>
            Object.keys(webRowData).every(key => webRowData[key].trim() === (row[key] || '').trim())
        );

        if (!matchingRow) {
            isMatched = false;
        }
    }

    return isMatched;
}
// Reusable method for getting row count
async function getRowCount(page, tableSelector) {
    const rows = await page.locator(`${tableSelector} tr`).count();
    return rows;
  }
  
  // Reusable method for getting column count
  async function getColumnCount(page, tableSelector) {
    const columns = await page.locator(`${tableSelector} tr:first-child td`).count();
    return columns;
  }
  
  // Reusable method for getting a specific cell value
  async function getCellValue(page, tableSelector, row, column) {
    const cell = await page.locator(`${tableSelector} tr:nth-child(${row}) td:nth-child(${column})`);
    return await cell.textContent();
  }
  
  // Reusable method for clicking a specific cell
  async function clickCell(page, tableSelector, row, column) {
    const cell = await page.locator(`${tableSelector} tr:nth-child(${row}) td:nth-child(${column})`);
    await cell.click();
  }
  
  // Reusable method for verifying a specific cell's value
  async function verifyCellValue(page, tableSelector, row, column, expectedValue) {
    const cellValue = await getCellValue(page, tableSelector, row, column);
    expect(cellValue.trim()).toBe(expectedValue);
  }
  
  // Reusable method to get all values in a row
  async function getRowValues(page, tableSelector, row) {
    const rowValues = await page.locator(`${tableSelector} tr:nth-child(${row}) td`).allTextContents();
    return rowValues;
  }
  
  // Reusable method to get all values in a column
  async function getColumnValues(page, tableSelector, column) {
    const columnValues = await page.locator(`${tableSelector} td:nth-child(${column})`).allTextContents();
    return columnValues;
  }
module.exports = { readExcelData, compareWebTableWithExcel, getRowCount,
    getColumnCount,
    getCellValue,
    clickCell,
    verifyCellValue,
    getRowValues,
    getColumnValues };
