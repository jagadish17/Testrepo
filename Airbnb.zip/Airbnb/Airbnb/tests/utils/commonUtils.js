//to navigate to a specific URL
module.exports.navigateToUrl = async (page, url) => {
  await page.goto(url, { waitUntil: 'networkidle' });
};

module.exports.clickElement = async (page, selector, options = {}) => {
  const { timeout = 5000, force = false, modifiers = undefined, delay = 0, clickCount = 1, position = undefined } = options;

  // Locate the element
  const element = page.locator(selector);

  // Ensure the element is visible and enabled before clicking
  await element.waitFor({ state: 'visible', timeout });

  // Perform the click action with optional parameters
  await element.click({ force, modifiers, delay, clickCount, position });
};

module.exports.fillTextField = async (page, selector, text, options = {}) => {
  const { timeout = 5000, clear = true, force = false, delay = 0 } = options;

  // Locate the input field
  const inputField = page.locator(selector);

  // Ensure the input field is visible before interacting
  await inputField.waitFor({ state: 'visible', timeout });

  // Clear existing text if needed
  if (clear) {
      await inputField.fill('');
  }

  // Fill the text field with the provided text
  await inputField.fill(text, { force });

  // Add an optional delay (for slow typing simulation)
  if (delay > 0) {
      await page.waitForTimeout(delay);
  }
};

module.exports.fillTextInputByRole=async(page, role, text)=> {
  await page.getByRole(role).fill(text);
};
module.exports. fillInputByLabel=async(page, label, text)=> {
  await page.getByLabel(label).fill(text);
};
module.exports. pressKey=async(page, key, delay = 0) =>{
  await page.keyboard.press(key, { delay });
};
//Verify that a specific text appears on the page or within an element.
module.exports.verifyTextContent = async (page, selector, expectedText, options = {}) => {
  const { timeout = 5000, exactMatch = false, ignoreCase = true, trimText = true } = options;

  // Locate the element
  const element = page.locator(selector);

  // Ensure the element is visible before checking text
  await element.waitFor({ state: 'visible', timeout });

  // Get the text content of the element
  let actualText = await element.textContent();

  // Handle optional text trimming
  if (trimText) {
      actualText = actualText.trim();
  }

  // Handle case sensitivity
  if (ignoreCase) {
      actualText = actualText.toLowerCase();
      expectedText = expectedText.toLowerCase();
  }

  // Perform exact or partial match check
  if (exactMatch) {
      if (actualText !== expectedText) {
          throw new Error(`Text does not match! Expected: "${expectedText}", but got: "${actualText}"`);
      }
  } else {
      if (!actualText.includes(expectedText)) {
          throw new Error(`Text does not contain expected value! Expected to find: "${expectedText}", but got: "${actualText}"`);
      }
  }

  console.log(`✅ Text verification passed! Found: "${actualText}"`);
};


//To upload a single file
module.exports.uploadSingleFile = async (page, selector, filePaths, options = {}) => {
  const { timeout = 5000, force = false } = options;

  // Locate the file input element
  const fileInput = page.locator(selector);

  // Ensure the input is visible and ready
  await fileInput.waitFor({ state: 'visible', timeout });

  // Upload the file(s)
  await fileInput.setInputFiles(filePaths, { force });
};
//To upload the multiple files
module.exports.uploadMultipleFiles = async (page, filePaths, targetSelector, options = {}) => {
  const { timeout = 5000, force = false } = options;

  // Resolve absolute paths for all files
  const resolvedPaths = filePaths.map(file => path.resolve(file));

  // Locate the file input element
  const inputElement = await page.locator(targetSelector);
  
  // Wait until the input is visible
  await inputElement.waitFor({ state: 'visible', timeout });

  // Set multiple files to the input field
  await inputElement.setInputFiles(resolvedPaths, { force });
};

//Performing mouse click
module.exports. clickElementWithMouse=async(page, selector, options = {})=> {
  const { button = 'left', clickCount = 1, delay = 0, timeout = 5000, force = false } = options;
  const element = page.locator(selector);
if(element){
  await element.waitFor({ state: 'visible', timeout });
  await element.click({ button, clickCount, delay, force });
}
else{
  throw new Error(`Element with selector: ${selector} not found`);
}
};

//performing right click 
module.exports. rightClick=async(page, selector, options = {})=> {
  const { button = 'right', clickCount = 1, delay = 0, timeout = 5000, force = false } = options;
  const element = page.locator(selector);
  if(element){
 // Ensure the element is visible before interacting
  await element.waitFor({ state: 'visible', timeout });
  // Perform right-click (context click)
  await element.click({ button, clickCount, delay, force });
  }
  else{
    throw new Error(`Element with selector: ${selector} not found`);
  }
};

 //to hover over an element and then click, such as on a menu or dropdown.
module.exports. hoverAndClick=async(page, selector, options = {})=> {
  const { timeout = 5000, delay = 0, force = false } = options;
  const element = page.locator(selector);
if(element){
  // Wait for the element to be visible
  await element.waitFor({ state: 'visible', timeout });

  // Hover over the element
  await element.hover();

  // Add a small delay (optional) after hovering before clicking
  if (delay > 0) {
      await page.waitForTimeout(delay);
  }

  // Click the element (with force option to handle non-interactive elements)
  await element.click({ force });
}
else{
  throw new Error(`Element with selector: ${selector} not found`);
}
}

// if we want to upload a file using mouse action below is the method 
module.exports.dragAndDropUploadFile = async (page, sourceFilePath, targetSelector) => {
  const element = await page.$(targetSelector);
  if (element) {
    // Use setInputFiles to upload the file to the input element
    await element.setInputFiles(sourceFilePath);
  } else {
    throw new Error(`Target element with selector: ${targetSelector} not found`);
  }
};

  //To simulate drag-and-drop behavior, useful for file uploads or any other draggable elements.
  module.exports.dragAndDrop = async (page, sourceSelector, targetSelector, options = {}) => {
    const { timeout = 5000 } = options;

    // Locate elements
    const source = page.locator(sourceSelector);
    const target = page.locator(targetSelector);

    // Ensure elements are visible
    await source.waitFor({ state: 'visible', timeout });
    await target.waitFor({ state: 'visible', timeout });

    // Perform drag and drop
    await source.dragTo(target);
};

 //A reusable method to hover over an element.
 module.exports.hoverOverElement = async (page, selector, options = {}) => {
  const { timeout = 5000, position = undefined, force = false } = options;

  // Use locator for better element handling
  const element = page.locator(selector);

  // Ensure the element is visible before hovering
  await element.waitFor({ state: 'visible', timeout });

  // Perform hover action with optional position and force parameters
  await element.hover({ position, force });
};


//A method to perform a double-click on an element.
module.exports.doubleClickElement = async (page, selector, options = {}) => {
  const { timeout = 5000, force = false, modifiers = undefined } = options;

  // Use locator for better handling
  const element = page.locator(selector);

  // Ensure the element is visible before double-clicking
  await element.waitFor({ state: 'visible', timeout });

  // Perform double-click with optional parameters
  await element.dblclick({ force, modifiers });
};




module.exports. waitForElementWithStateVisible=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'visible' } = options;

  // Wait for the element with the specified state=Visible and timeout
  const element=await page.waitForSelector(selector, { state, timeout });
  if (!element) {
    throw new Error(`Element with selector: ${selector} did not visible within ${timeout}ms`);
  }

  return page.locator(selector); // Return locator for further use
};
module.exports. waitForElementWithStateAttached=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'attached' } = options;

  // Wait for the element with the specified state=attached and timeout
  const element=await page.waitForSelector(selector, { state, timeout });
  if (!element) {
    throw new Error(`Element with selector: ${selector} did not attached within ${timeout}ms`);
  }

  return page.locator(selector); // Return locator for further use
};

module.exports. waitForElementWithStateHidden=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'hidden' } = options;

  // Wait for the element with the specified state=attached and timeout
  const element= await page.waitForSelector(selector, { state, timeout });
  if (!element) {
    throw new Error(`Element with selector: ${selector} did not disappear within ${timeout}ms`);
  }

  return page.locator(selector); // Return locator for further use
};

module.exports. waitForElementWithStateDetached=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'detached' } = options;

  // Wait for the element with the specified state=attached and timeout
  const element=await page.waitForSelector(selector, { state, timeout });
  if (!element) {
    throw new Error(`Element with selector: ${selector} did not removed within ${timeout}ms`);
  }
  return page.locator(selector); // Return locator for further use
};

 
     //Sometimes, elements take time to appear on the page. A utility to wait for an element.
  module.exports.waitForSelectorWithTimeOut = async (page, selector, timeout=5000) => {
    const element = await page.waitForSelector(selector, { timeout });
    if (!element) {
      throw new Error(`Element with selector: ${selector} did not appear within ${timeout}ms`);
    }
  };

  //Wait for the page navigation to complete, particularly useful when the page reloads after an action like form submission.
  module.exports.waitForNavigation = async (page, timeout = 5000) => {
    const element = await page.waitForNavigation({ waitUntil: 'load', timeout });
    if (!element) {
      throw new Error(`Page did not load within specified time ${timeout}ms`);
    }
  };
  
  //wait for the element with locator and timeout is 5 sec if we want to increase the timeout pass the parameter as options{timeout = 10000}
module.exports. waitForLocatorwithStateVisible=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'visible' } = options;
  const element = page.locator(selector);

  // Wait for the element with the specified state and timeout
  await element.waitFor({ state, timeout });
  if (!element) {
    throw new Error(`Element with locator: ${selector} did not appear within ${timeout}ms`);
  }

  return element; // Return the locator for further actions if needed
};

module.exports. waitForLocatorwithStateHidden=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'hidden' } = options;
  const element = page.locator(selector);

  // Wait for the element with the specified state and timeout
  await element.waitFor({ state, timeout });
  if (!element) {
    throw new Error(`Element with locator: ${selector} did not disappear within ${timeout}ms`);
  }
  return element; // Return the locator for further actions if needed
};
module.exports. waitForLocatorwithStateAttached=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'attached' } = options;
  const element = page.locator(selector);

  // Wait for the element with the specified state and timeout
  await element.waitFor({ state, timeout });
  if (!element) {
    throw new Error(`Element with locator: ${selector} did not attached within ${timeout}ms`);
  }
  return element; // Return the locator for further actions if needed
};
module.exports. waitForLocatorwithStateDetached=async(page, selector, options = {})=> {
  const { timeout = 5000, state = 'detached' } = options;
  const element = page.locator(selector);

  // Wait for the element with the specified state and timeout
  await element.waitFor({ state, timeout });
  if (!element) {
    throw new Error(`Element with locator: ${selector} did not removed within ${timeout}ms`);
  }
  return element; // Return the locator for further actions if needed
};             
//This method waits until a specific text appears in the DOM.Alternative way for WaitForSelector
module.exports. waitForText=async(page, text, timeout = 5000)=> {
  return await page.waitForFunction(
      text => document.body.innerText.includes(text),
      text,
      { timeout }
  );
};
//This method waits until an element’s attribute matches a given value.
module.exports. waitForAttribute=async(page, selector, attribute, value, timeout = 5000)=> {
  return await page.waitForFunction(
      (selector, attribute, value) => document.querySelector(selector)?.getAttribute(attribute) === value,
      selector, attribute, value,
      { timeout }
  );
};
//This method waits until an element’s computed style changes to a specific value.
module.exports.waitForCSS=async(page, selector, property, value, timeout = 5000)=> {
  return await page.waitForFunction(
      (selector, property, value) => getComputedStyle(document.querySelector(selector))[property] === value,
      selector, property, value,
      { timeout }
  );
};
//This method waits until all network requests are idle.
module.exports. waitForNetworkIdle=async(page, timeout = 5000) =>{
  await page.waitForFunction(() => window.performance.getEntriesByType('resource').every(e => e.responseEnd), { timeout });
};
//This method waits until a specific message appears in the browser console.
module.exports. waitForConsoleMessage=async(page, message, timeout = 5000)=> {
  return await page.waitForFunction(
      message => window.consoleLogs && window.consoleLogs.includes(message),
      message,
      { timeout }
  );
};
//method ensure that the page has navigated to the expected URL before proceeding with further actions.
module.exports.waitForURL = async (page, expectedUrl, options = {}) => {
  const { timeout = 30000 } = options;

  try {
      await page.waitForURL(expectedUrl, { timeout });
      console.log(`Navigation to URL matching '${expectedUrl}' was successful.`);
  } catch (error) {
      throw new Error(`Timeout of ${timeout}ms exceeded while waiting for URL to match '${expectedUrl}'.`);
  }
};
//ensuring that your test proceeds only after the desired network response is received.
module.exports. waitForNetworkResponse=async(page, urlPart, status = 200, timeout = 30000)=> {
  try {
      const response = await page.waitForResponse(
          response => response.url().includes(urlPart) && response.status() === status,
          { timeout }
      );
      return response;
  } catch (error) {
      throw new Error(`No response matching criteria: URL containing '${urlPart}' with status ${status} within ${timeout}ms`);
  }
};
//method to waits for a specific network request
module.exports. waitForNetworkRequest=async(page, urlPart, timeout = 30000)=> {
  try {
      const request = await page.waitForRequest(
          request => request.url().includes(urlPart),
          { timeout }
      );
      return request;
  } catch (error) {
      throw new Error(`No request matching criteria: URL containing '${urlPart}' within ${timeout}ms`);
  }
};
//Method to listen for specific event
module.exports.waitForEvent=async(page, eventName, callback)=> {
  await page.once(eventName, callback);
};
//Listens for multiple occurrences of an event.
module.exports.listenForEvent=async(page, eventName, callback)=> {
  page.on(eventName, callback);
};
//browser close
module.exports. closeBrowser=async(browser)=> {
  await browser.close();
};
//to capture screenshots after a test step or on failure.
module.exports.takeScreenshot = async (page, fileName) => {
  const timestamp = new Date().toISOString().replace(/[:.-]/g, '_'); // Format timestamp for file names
  await page.screenshot({ path: `screenshots/${fileName || timestamp}.png` });
};
//Handling Alerts
module.exports = {
  /**
   * Accepts an alert popup.
   * @param {Page} page - Playwright page object.
   */
  acceptAlert: async (page) => {
      page.once('dialog', async (dialog) => {
          console.log(`🛑 Alert Text: ${dialog.message()}`);
          await dialog.accept();
      });
  },

  /**
   * Dismisses an alert popup.
   * @param {Page} page - Playwright page object.
   */
  dismissAlert: async (page) => {
      page.once('dialog', async (dialog) => {
          console.log(`🛑 Alert Text: ${dialog.message()}`);
          await dialog.dismiss();
      });
  },

  /**
   * Accepts a confirmation popup.
   * @param {Page} page - Playwright page object.
   */
  acceptConfirmation: async (page) => {
      page.once('dialog', async (dialog) => {
          console.log(`✅ Confirmation Text: ${dialog.message()}`);
          await dialog.accept();
      });
  },

  /**
   * Dismisses a confirmation popup.
   * @param {Page} page - Playwright page object.
   */
  dismissConfirmation: async (page) => {
      page.once('dialog', async (dialog) => {
          console.log(`❌ Confirmation Text: ${dialog.message()}`);
          await dialog.dismiss();
      });
  },

  /**
   * Handles a prompt popup and enters the given text.
   * @param {Page} page - Playwright page object.
   * @param {string} text - Text to enter in the prompt.
   */
  handlePrompt: async (page, text = '') => {
      page.once('dialog', async (dialog) => {
          console.log(`💬 Prompt Text: ${dialog.message()}`);
          await dialog.accept(text);
      });
  },

  /**
   * Returns the alert message text.
   * @param {Page} page - Playwright page object.
   * @returns {Promise<string>} - The alert text.
   */
  getAlertText: async (page) => {
      return new Promise((resolve) => {
          page.once('dialog', async (dialog) => {
              console.log(`📢 Alert Message: ${dialog.message()}`);
              resolve(dialog.message());
              await dialog.dismiss(); // Dismiss after retrieving text
          });
      });
  }
};
//A method to clear any pre-filled input fields
module.exports.clearInputField = async (page, selector) => {
  const inputElement = await page.$(selector);
  if (inputElement) {
      // Focus on the input field to ensure it's active
      await inputElement.focus();
      // Clear the input field
      await inputElement.fill('');
  } else {
      throw new Error(`Input element with selector: ${selector} not found`);
  }
};
//A method to fetch the page title
module.exports.getPageTitle = async (page) => {
  const title = await page.title();
  return title;
};

 //Retrieve an attribute value from an element.
 module.exports.getElementAttribute = async (page, selector, attribute) => {
  const element = await page.$(selector); // Get the element based on the selector
  if (element) {
      // Retrieve the value of the specified attribute
      const attributeValue = await element.getAttribute(attribute);
      return attributeValue; // Return the attribute value
  } else {
      throw new Error(`Element with selector: ${selector} not found`);
  }
};

 //To check how many elements match a given selector, which can be useful to validate lists or dynamic content.
 module.exports.getElementCount = async (page, selector) => {
  const elements = await page.$$(selector); // Get all elements matching the selector
  return elements.length; // Return the count of elements
};
//For verifying the state of a checkbox (checked or unchecked).
module.exports.isCheckboxChecked = async (page, selector) => {
  const checkbox = await page.$(selector); // Get the checkbox element based on the selector
  if (checkbox) {
      // Check if the checkbox is checked
      const isChecked = await checkbox.isChecked;
      return isChecked; // Return the status (true or false)
  } else {
      throw new Error(`Checkbox with selector: ${selector} not found`);
  }
};

//Check whether an element is visible on the page or not.
module.exports.isElementVisible = async (page, selector) => {
  const element = await page.$(selector); // Get the element based on the selector
  if (element) {
      const isVisible = await element.isVisible(); // Check if the element is visible
      return isVisible; // Return the visibility status (true or false)
  } else {
      throw new Error(`Element with selector: ${selector} not found`);
  }
};
 //Extract all links (href) from the page.
 module.exports.getAllLinks = async (page) => {
  // Get all anchor elements <a> on the page
  const links = await page.$$eval('a', (anchors) => anchors.map(anchor => anchor.href));
  return links; // Return an array of all the href values (URLs)
};

  //To retrieve the current URL of the page. Useful for validations.
  module.exports.getPageUrl = async (page) => {
    const url = page.url(); // Get the current page URL
    return url; // Return the URL
};
 //Check if a particular element (like a button or input) is disabled.
 module.exports.isElementDisabled = async (page, selector) => {
  const element = await page.$(selector); // Get the element based on the selector
  if (element) {
      // Check if the element is disabled
      const isDisabled = await element.isDisabled();
      return isDisabled; // Return the status (true or false)
  } else {
      throw new Error(`Element with selector: ${selector} not found`);
  }
};
 //specific element, like a button or input field, is enabled.
 module.exports.isElementEnabled = async (page, selector) => {
  const element = await page.$(selector); // Get the element based on the selector
  if (element) {
      // Check if the element is visible and not disabled
      const isDisabled = await element.isDisabled();
      const isVisible = await element.isVisible();
      return !isDisabled && isVisible; // Return true if element is visible and not disabled
  } else {
      throw new Error(`Element with selector: ${selector} not found`);
  }
};

//Useful for debugging to capture the entire HTML source of the page.
module.exports.capturePageSource = async (page) => {
  try {
      // Get the HTML source of the page
      const pageSource = await page.content();
      return pageSource; // Return the HTML content
  } catch (error) {
      throw new Error('Error capturing page source: ' + error.message);
  }
};
//to type the text in textbox
module.exports.typeText = async(page, selector, text, options = {}) => {
  const { delay = 0, clear = true, timeout = 5000 } = options;
  const element = page.locator(selector);

  // Ensure the element is visible and interactive before typing
  await element.waitFor({ state: 'visible', timeout });

  // Optionally clear the existing text before typing
  if (clear) {
      await element.fill('');
  }

  // Type the text with optional delay
  await element.type(text, { delay, force });
};

//to verify the title of the page
module.exports.verifyPageTitle = async (page, expectedTitle) => {
  try {
      // Get the current title of the page
      const actualTitle = await page.title();
      
      // Compare the actual title with the expected title
      if (actualTitle === expectedTitle) {
          return true; // Titles match
      } else {
          throw new Error(`Title mismatch: Expected '${expectedTitle}', but found '${actualTitle}'`);
      }
  } catch (error) {
      throw new Error('Error verifying page title: ' + error.message);
  }
};
//Go Back to the previous page
module.exports. goBack=async(page)=> {
  await page.goBack();
};
//Navigate to next page
module.exports. goForward=async(page)=> {
  await page.goForward();
};
//method to focus on a specific element.
module.exports. focusElement=async(page, selector)=> {
  await page.focus(selector);
};
//method that retrieves the currently focused element on a page
module.exports. getFocusedElement=async(page)=> {
  return await page.evaluateHandle(() => document.activeElement);
};
/**
 * Launches the specified number of browser instances of the given type with the provided options.
 *
 * @param {string} browserType - The type of browser to launch ('chromium', 'firefox', or 'webkit').
 * @param {number} [count=1] - The number of browser instances to launch.
 * @param {Object} [options] - Configuration options for launching the browsers.
 * @param {boolean} [options.headless=true] - Whether to run in headless mode.
 * @param {boolean} [options.slowMo=0] - Slow down Playwright operations by the specified amount of milliseconds.
 * @param {boolean} [options.devtools=false] - Whether to open DevTools upon launch.
 * @returns {Promise<Browser[]>} - Resolves to an array of launched browser instances.
 */
module.exports. launchBrowsers=async(browserType, count = 1, { headless = true, slowMo = 0, devtools = false } = {}) =>{
  const { chromium, firefox, webkit } = require('playwright');

  let browser;
  switch (browserType.toLowerCase()) {
      case 'chromium':
          browser = chromium;
          break;
      case 'firefox':
          browser = firefox;
          break;
      case 'webkit':
          browser = webkit;
          break;
      default:
          throw new Error(`Unsupported browser type: ${browserType}`);
  }

  const browsers = [];
  for (let i = 0; i < count; i++) {
      browsers.push(await browser.launch({ headless, slowMo, devtools }));
  }
  return browsers;
};

/**
 * Performs a click on the specified selector with optional modifier keys.
 *
 * @param {string} selector - The CSS selector of the element to click.
 * @param {Array<string>} [modifiers] - An array of modifier keys to press during the click (e.g., ['Shift', 'Control']).
 * @returns {Promise<void>} - Resolves when the click action is completed.
 */
module.exports. clickWithModifiers=async(page, selector, modifiers = [])=> {
  const modifierMap = {
      'Shift': 'Shift',
      'Control': 'Control',
      'Alt': 'Alt',
      'Meta': 'Meta',
  };

  // Validate modifiers
  for (const modifier of modifiers) {
      if (!modifierMap[modifier]) {
          throw new Error(`Unsupported modifier: ${modifier}`);
      }
  }

  // Perform the click with the specified modifiers
  await page.locator(selector).click({ modifiers });
};

module.exports. clickWithOptions=async(page, selector, clickCount = 1, delay = 0)=> {
  for (let i = 0; i < clickCount; i++) {
      await page.locator(selector).click();
      if (i < clickCount - 1) {
          await page.waitForTimeout(delay);
      }
  }
};
module.exports.tapAtCoordinates=async(page, x, y)=> {
  await page.touchscreen.tap(x, y);
};    
  
//Method to handle dropdown bey default it will select the options based on label. pass the other type if requiredp

module.exports.selectDropdown = async (page, selector, option, type = 'label', options = {}) => {
  const { timeout = 5000, force = false } = options;

  // Locate dropdown
  const dropdown = page.locator(selector);

  // Ensure dropdown is visible
  await dropdown.waitFor({ state: 'visible', timeout });

  // Select based on type
  switch (type) {
      case 'value':
          await dropdown.selectOption({ value: option }, { force });
          break;
      case 'index':
          await dropdown.selectOption({ index: parseInt(option) }, { force });
          break;
      case 'label':
      default:
          await dropdown.selectOption({ label: option }, { force });
          break;
  }
};

module.exports. getFrame=async(page, identifier)=> {
  const frames = page.frames();
  for (const frame of frames) {
      if (frame.name() === identifier || frame.url().includes(identifier)) {
          return frame;
      }
  }
  return null;
};
//perform click within frames
module.exports. clickElementInFrame=async(page, frameIdentifier, selector)=> {
  const frame = await getFrame(page, frameIdentifier);
  if (frame) {
      await frame.click(selector);
  } else {
      console.error(`Frame with identifier "${frameIdentifier}" not found.`);
  }
};
module.exports. fillInputInFrame=async(page, frameIdentifier, selector, value)=> {
  const frame = await getFrame(page, frameIdentifier);
  if (frame) {
      await frame.fill(selector, value);
  } else {
      console.error(`Frame with identifier "${frameIdentifier}" not found.`);
  }
};
module.exports.pause=async(page)=> {
  await page.pause();
}; 
//Close a new tab or popup that has opened after an action.
  module.exports.closePopup = async (context) => {
    const pages = await context.pages();
    if (pages.length > 1) {
      const popup = pages[pages.length - 1];
      await popup.close();
    }
  };
  //To select all the text
  module.exports. selectText=async(locator)=> {
    await locator.selectText();
};
//select the text along with actionability

module.exports. selectTextWithActions=async(locator,options={})=> {

  await locator.selectText(options);
};
//set the CheokBox or RadioButton as true
module.exports. setChecked=async(locator, checked = true, options = {})=> {
  const { force = false, timeout = 5000 } = options;

  // Wait for the element to be actionable
  await locator.waitFor({ state: 'attached', timeout });

  // Set the checked state
  await locator.setChecked(checked, { force, timeout });
};



//unCheck the radioButton or check Box
module.exports. uncheck=async(locator, options = {}) =>{
  const { force = false, timeout = 5000 } = options;

  // Wait for the element to be actionable
  await locator.waitFor({ state: 'attached', timeout });

  // Uncheck the element
  await locator.uncheck({ force, timeout });
};

module.exports. selectMultipleOptions=async(locator, options, optionsConfig = {})=> {
  const { timeout = 5000 } = optionsConfig;

  // Wait for the <select> element to be attached to the DOM
  await locator.waitFor({ state: 'attached', timeout });

  // Select the specified options
  await locator.selectOption(options.map(value => ({ label: value })));
};

  //to scroll the page to make an element visible.
  module.exports.scrollToElement = async (page, selector) => {
    const element = await page.$(selector);
    if (element) {
      await element.scrollIntoViewIfNeeded();
    } else {
      throw new Error(`Element with selector: ${selector} not found`);
    }
  };
  
  //Useful for pages that have infinite scroll or long content.
  module.exports.scrollToBottom = async (page) => {
    await page.evaluate(() => {
      window.scrollTo(0, document.body.scrollHeight);
    });
  };
//Scroll the page by a specific distance, either horizontally or vertically.
  module.exports.scrollBy = async (page, x = 0, y = 500) => {
    await page.evaluate((x, y) => {
      window.scrollBy(x, y);
    }, x, y);
  };
  

















  
//If a new tab opens during the test, this method allows switching to the newly opened tab.
module.exports.switchToNewTab = async (context) => {
    const pages = await context.pages();
    const newTab = pages[pages.length - 1]; // Last opened page
    return newTab;
  };
//to know the position and size of an element on the page. This method returns the bounding box of an element.
  module.exports.getElementBoundingBox = async (page, selector) => {
    const element = await page.$(selector);
    if (element) {
      const boundingBox = await element.boundingBox();
      return boundingBox;
    } else {
      throw new Error(`Element with selector: ${selector} not found`);
    }
  };
  //A method to clear all cookies from the current page or context, which is useful for tests requiring a fresh session.
  module.exports.clearCookies = async (context) => {
    const cookies = await context.cookies();
    if (cookies.length > 0) {
      await context.clearCookies();
    }
  };
  //retrieve all cookies
  module.exports.getAllCookies = async (context) => {
    const cookies = await context.cookies();
    return cookies;
  };
 
/**
//select the value from the dropdown using label
module.exports. selectByLabel=async(page, selector, label, isCustom = false)=> {
  const element = page.locator(selector);

  // Ensure the dropdown is visible before interacting
  await element.waitFor({ state: 'visible' });

  if (isCustom) {
      // Custom dropdown: Click to open, then select the option
      await element.click();
      await page.click(`text="${label}"`);
  } else {
      // Standard <select> dropdown: Use Playwright's built-in selectOption method
      await element.selectOption({ label });
  }
};
 */






