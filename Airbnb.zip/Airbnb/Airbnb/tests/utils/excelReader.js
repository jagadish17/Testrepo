const xlsx = require("xlsx");



function fetchValueBySearch(filePath, sheetName, searchColumn, searchValue, targetColumn) {
    const workbook = xlsx.readFile(filePath);
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) {
        throw new Error(`Sheet "${sheetName}" not found in the file.`);
    }

    const jsonData = xlsx.utils.sheet_to_json(sheet);

    if (!jsonData.length) {
        throw new Error(`Sheet "${sheetName}" is empty.`);
    }
    console.log('Sheet Data:', jsonData);
    console.log(`Searching for value: "${searchValue}" in column: "${searchColumn}"`);
    //const matchingRow = jsonData.find(row => row[searchColumn]?.toString() === searchValue.toString());
    const matchingRow = jsonData.find(row => row[searchColumn]?.toString().trim().toLowerCase() === searchValue.toString().trim().toLowerCase());


    if (!matchingRow) {
        throw new Error(`No match found for ${searchValue} in column "${searchColumn}".`);
    }

    if (!matchingRow[targetColumn]) {
        throw new Error(`Target column "${targetColumn}" has no value for ${searchValue}.`);
    }

    return matchingRow[targetColumn];
}

module.exports = { fetchValueBySearch };
