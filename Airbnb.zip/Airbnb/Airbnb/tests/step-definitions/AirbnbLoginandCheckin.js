const { Given, When, Then } = require('@cucumber/cucumber');
const { chromium } = require('playwright');
const AirbnbPage = require('../pages/AirbnbLoginandCheckin');

let browser, page, airbnb;

Given('user navigates to the URL', async function () {
    /* browser = await chromium.launch({ headless: false });
    page = await browser.newPage(); */
    airbnb = new AirbnbPage(this.page); 
    await airbnb.navigate();
});

When('user enters destination in the location field', async function () {
    await airbnb.enterDestination();
});

When('user clicks United States from the destination', async function () {
    await airbnb.selectDestination();
});

When('user chooses the check-in date', async function () {
    await airbnb.chooseCheckinDate();
});

When('user chooses the checkout date', async function () {
    await airbnb.chooseCheckoutDate();
});

When('user clicks add guest option', async function () {
    await airbnb.clickAddGuest();
});

When('user clicks plus button to add the Adult guest', async function () {
    await airbnb.addAdultGuest();
});

When('user clicks plus button again to add Children guest', async function () {
    await airbnb.addChildGuest();
});

When('user clicks plus button again to add Infant guest', async function () {
    await airbnb.addInfantGuest();
});

When('user clicks search button for searching hotels', async function () {
    await airbnb.clickSearchButton();
});

Then('user verifies United States in the search page', async function () {
    await airbnb.verifySearchResults();
    await browser.close();
});
