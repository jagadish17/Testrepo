const { Before, After, AfterAll, setDefaultTimeout, Status } = require('@cucumber/cucumber');
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

let browser, context, page;
setDefaultTimeout(60 * 1000);
let failedScenarios = [];

Before(async function (scenario) {
    const requiresLogin = scenario.pickle.tags.some(tag => tag.name === '@requiresLogin');

    if (!browser) {
        console.log("🚀 Launching browser...");
        browser = await chromium.launch({ headless: false });
    }

    if (!context || requiresLogin) {
        console.log("🌐 Creating new context...");
        context = await browser.newContext();
        page = await context.newPage();
        
        this.page = page;
        this.context = context;
    }
});

After(async function (scenario) {
    if (scenario.result?.status === Status.FAILED) {
        console.log(`❌ Scenario failed: ${scenario.pickle.name}`);
        failedScenarios.push(scenario.pickle.name);

        if (this.page) {
            const screenshotDir = path.resolve(__dirname, '../screenshots');
            if (!fs.existsSync(screenshotDir)) {
                fs.mkdirSync(screenshotDir, { recursive: true });
            }

            const screenshotPath = path.join(screenshotDir, `${scenario.pickle.name.replace(/\s+/g, '_')}.png`);
            await this.page.screenshot({ path: screenshotPath });

            this.attach(fs.readFileSync(screenshotPath), 'image/png');
        }
    }

    if (this.context) {
        console.log("🔄 Closing context after scenario...");
        await this.context.close();
    }
});

AfterAll(async function () {
    console.log("🛑 Closing browser...");
    if (browser) {
        await browser.close();
    }

    console.log(`⚠️ Failed Scenarios: ${failedScenarios.length}`);
    if (failedScenarios.length > 0) {
        console.log("🔄 Retrying failed scenarios...");
        await retryFailedScenarios(failedScenarios, 1);
    }
});

async function retryFailedScenarios(failedScenarios, maxRetries) {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        console.log(`🔁 Retrying failed scenarios (Attempt: ${attempt})`);

        for (const scenario of failedScenarios) {
            console.log(`🔄 Re-running failed scenario: ${scenario}`);
            await runCucumberScenario(scenario);
        }
    }
}

function runCucumberScenario(scenarioName) {
    return new Promise((resolve, reject) => {
        exec(
           ` npx cucumber-js --require tests/support/hooks.js --format json:./allure-results/results.json --name "${scenarioName}"`,
            { timeout: 120000 },
            (error, stdout, stderr) => {
                if (error) {
                    console.error(`🚨 Error: ${error.message}`);
                    reject(error);
                }
                if (stderr) console.warn(`⚠️ stderr: ${stderr}`);
                console.log(`📜 stdout: ${stdout}`);
                resolve();
            }
        );
    });
} 